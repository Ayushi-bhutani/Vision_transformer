set -x -e

bash tools/run_gpu_tests.sh
